module.exports = {
    errorMessage:{status:"failed"},
    successMessage:{status:"success"},
    successRegister:{status:"success",message:"already registerd"}
}